"""Pakiet uczenia maszynowego dla projektu badawczego - analiza sygnału EEG i klasyfikacja emocji"""
